import http from "k6/http";
import { check, sleep } from "k6";
import { Rate } from "k6/metrics";

// Custom metrics
const errorRate = new Rate("errors");

// Test configuration
export const options = {
  // Scenario 1: Smoke Test (2 VUs for 30s)
  // Scenario 2: Load Test (10 VUs for 2 minutes)
  // Scenario 3: Stress Test (Ramp up to 50 VUs)

  stages: [
    { duration: "30s", target: 5 }, // Warm up: 5 users
    { duration: "1m", target: 10 }, // Normal load: 10 users
    { duration: "30s", target: 20 }, // Peak load: 20 users
    { duration: "1m", target: 20 }, // Sustained peak
    { duration: "30s", target: 0 }, // Cool down
  ],

  thresholds: {
    http_req_duration: ["p(95)<2000"], // 95% of requests should be below 2s
    http_req_failed: ["rate<0.1"], // Error rate should be less than 10%
    errors: ["rate<0.1"], // Custom error rate < 10%
  },
};

// Base URL - SESUAIKAN DENGAN URL ANDA
const BASE_URL = "http://localhost/hotel/project";

// Test data
const testUsers = [
  { name: "Test User 1", email: "user1@test.com", phone: "081234567890" },
  { name: "Test User 2", email: "user2@test.com", phone: "081234567891" },
  { name: "Test User 3", email: "user3@test.com", phone: "081234567892" },
];

export function setup() {
  console.log("=== Starting Performance Test ===");
  console.log(`Base URL: ${BASE_URL}`);
  console.log(`VUs: ${__ENV.VUS || "Dynamic (see stages)"}`);
  console.log(`Duration: ${__ENV.DURATION || "Dynamic (see stages)"}`);
}

export default function () {
  const user = testUsers[Math.floor(Math.random() * testUsers.length)];

  // Test 1: Load Homepage
  testHomePage();
  sleep(1);

  // Test 2: View Reservation Page
  testReservationPage();
  sleep(1);

  // Test 3: Submit Reservation
  testSubmitReservation(user);
  sleep(2);

  // Test 4: View Contact Page
  testContactPage();
  sleep(1);

  // Test 5: Submit Contact Message
  testSubmitMessage(user);
  sleep(2);

  // Test 6: Admin Login
  testAdminLogin();
  sleep(1);
}

// Test Functions
function testHomePage() {
  const res = http.get(`${BASE_URL}/index.php`);

  const result = check(res, {
    "Homepage status is 200": (r) => r.status === 200,
    "Homepage loads in < 2s": (r) => r.timings.duration < 2000,
    "Homepage contains header": (r) => r.body.includes("header"),
  });

  errorRate.add(!result);
}

function testReservationPage() {
  const res = http.get(`${BASE_URL}/index.php#reservation`);

  const result = check(res, {
    "Reservation page status is 200": (r) => r.status === 200,
    "Reservation page loads in < 2s": (r) => r.timings.duration < 2000,
    "Reservation form exists": (r) => r.body.includes("reservation"),
  });

  errorRate.add(!result);
}

function testSubmitReservation(user) {
  const payload = {
    name: user.name,
    email: user.email,
    number: user.phone,
    rooms: "1",
    check_in: "20/12/2025",
    check_out: "25/12/2025",
    adults: "2",
    children: "1",
  };

  const params = {
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  };

  const res = http.post(`${BASE_URL}/reservation.php`, payload, params);

  const result = check(res, {
    "Reservation submit status is 200 or 302": (r) =>
      r.status === 200 || r.status === 302,
    "Reservation submits in < 3s": (r) => r.timings.duration < 3000,
  });

  errorRate.add(!result);
}

function testContactPage() {
  const res = http.get(`${BASE_URL}/index.php#contact`);

  const result = check(res, {
    "Contact page status is 200": (r) => r.status === 200,
    "Contact form exists": (r) => r.body.includes("contact"),
  });

  errorRate.add(!result);
}

function testSubmitMessage(user) {
  const payload = {
    name: user.name,
    email: user.email,
    number: user.phone,
    message: "Load testing message - " + new Date().toISOString(),
  };

  const params = {
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  };

  const res = http.post(`${BASE_URL}/contact.php`, payload, params);

  const result = check(res, {
    "Message submit status is 200 or 302": (r) =>
      r.status === 200 || r.status === 302,
    "Message submits in < 3s": (r) => r.timings.duration < 3000,
  });

  errorRate.add(!result);
}

function testAdminLogin() {
  const payload = {
    name: "admin",
    pass: "111",
  };

  const params = {
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  };

  const res = http.post(`${BASE_URL}/admin/login.php`, payload, params);

  const result = check(res, {
    "Admin login status is 200 or 302": (r) =>
      r.status === 200 || r.status === 302,
    "Admin login responds in < 2s": (r) => r.timings.duration < 2000,
  });

  errorRate.add(!result);
}

export function teardown(data) {
  console.log("=== Performance Test Completed ===");
}

/* ============================================
   CARA MENJALANKAN TEST
   ============================================

1. SMOKE TEST (Quick sanity check)
   k6 run --vus 1 --duration 30s hotel_performance_test.js

2. LOAD TEST (Normal load)
   k6 run --vus 10 --duration 2m hotel_performance_test.js

3. STRESS TEST (Find breaking point)
   k6 run --vus 50 --duration 3m hotel_performance_test.js

4. SPIKE TEST (Sudden traffic surge)
   k6 run --vus 100 --duration 1m hotel_performance_test.js

5. CUSTOM STAGES (Using predefined stages in options)
   k6 run hotel_performance_test.js

6. GENERATE HTML REPORT
   k6 run --out json=results.json hotel_performance_test.js
   
7. CLOUD TEST (Optional - requires k6 Cloud account)
   k6 cloud hotel_performance_test.js

============================================
   METRICS YANG DIUKUR
============================================

- http_req_duration: Response time
- http_req_failed: Failed requests rate
- http_reqs: Total requests per second
- vus: Virtual users
- iterations: Complete test iterations
- data_received: Total data downloaded
- data_sent: Total data uploaded

============================================
   THRESHOLDS (Pass/Fail Criteria)
============================================

- 95% requests must complete under 2 seconds
- Error rate must be less than 10%
- All checks must pass

============================================ */
