<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <a href="tel:+62812345678"><i class="fas fa-phone"></i> +62-812-345-678</a>
         <a href="tel:+62213456789"><i class="fas fa-phone"></i> +62-21-345-6789</a>
         <a href="mailto:info@grandvisita.com"><i class="fas fa-envelope"></i> info@grandvisita.com</a>
         <a href="mailto:booking@grandvisita.com"><i class="fas fa-envelope"></i> booking@grandvisita.com</a>
         <a href="#"><i class="fas fa-map-marker-alt"></i> Salatiga, Central Java - 51024</a>
      </div>

      <div class="box">
         <a href="#home">home</a>
         <a href="#about">about</a>
         <a href="bookings.php">my bookings</a>
         <a href="#reservation">reservation</a>
         <a href="#gallery">gallery</a>
         <a href="#contact">contact</a>
         <a href="#reviews">reviews</a>
      </div>

      <div class="box">
         <a href="#">facebook <i class="fab fa-facebook-f"></i></a>
         <a href="#">twitter <i class="fab fa-twitter"></i></a>
         <a href="#">instagram <i class="fab fa-instagram"></i></a>
         <a href="#">linkedin <i class="fab fa-linkedin"></i></a>
         <a href="#">youtube <i class="fab fa-youtube"></i></a>
      </div>

   </div>

   <div class="credit">&copy; copyright @ 2024 Grand Visita Hotel | all rights reserved!</div>

</section>

<!-- footer section ends -->