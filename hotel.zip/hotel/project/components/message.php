<?php

if(!empty($success_msg) && is_array($success_msg)){
   foreach($success_msg as $msg){
      echo '<script>swal(' . json_encode($msg) . ', "" ,"success");</script>';
   }
}

if(!empty($warning_msg) && is_array($warning_msg)){
   foreach($warning_msg as $msg){
      echo '<script>swal(' . json_encode($msg) . ', "" ,"warning");</script>';
   }
}

if(!empty($info_msg) && is_array($info_msg)){
   foreach($info_msg as $msg){
      echo '<script>swal(' . json_encode($msg) . ', "" ,"info");</script>';
   }
}

if(!empty($error_msg) && is_array($error_msg)){
   foreach($error_msg as $msg){
      echo '<script>swal(' . json_encode($msg) . ', "" ,"error");</script>';
   }
}

?>
